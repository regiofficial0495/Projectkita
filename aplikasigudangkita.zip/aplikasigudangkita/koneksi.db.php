<?php
$host="localhost";
$user="root";
$pass="";
$db="gudangkita";
$koneksi=mysqli_connect($host,$user,$pass,$db) or die ('Gagal koneksi server !');
?>